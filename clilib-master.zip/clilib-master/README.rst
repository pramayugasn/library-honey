======
clilib
======

``clilib`` is a library for the emulating command line commands.

-----
usage
-----
::

    from clilib import *
    
    print uname()
    print uname('-a')
    print man('uname')
    print echo('test')
    print whoami('root')



More details and the latest updates can be found on the `GitHub Project Page`_.

.. _GitHub Project Page: https://github.com/foospidy/clilib
