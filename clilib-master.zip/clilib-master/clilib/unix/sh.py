def sh(params=None):
	"""
No manual entry for cd
	"""
	return ''
