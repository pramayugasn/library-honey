def cd(params=None):
	"""
No manual entry for cd
	"""
	return ''
