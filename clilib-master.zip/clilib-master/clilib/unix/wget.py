def wget(params=None):
	"""
No manual entry for wget
	"""
	return ''
